/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;


public class cus_det {
    
private int id,mobile;  
    private String fname,lname,email;  
public int getId() {  
    return id;  
}  
public void setId(int id) {  
    this.id = id;  
}  
public String getFName() {  
    return fname;  
}  
public void setFName(String fname) {  
    this.fname = fname;  
}  
public String getLName() {  
    return lname;  
}  
public void setLName(String lname) {  
    this.lname = lname;  
}  
public int getMobile() {  
    return mobile;  
}  
public void setMobile(int mobile) {  
    this.mobile = mobile;  
}  
public String getEmail() {  
    return email;  
}  
public void setEmail(String email) {  
    this.email = email;  
}  
}
