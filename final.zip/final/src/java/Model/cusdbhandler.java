package Model;


import Model.cus;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Intel
 */
public class cusdbhandler {
    
public static Connection getConnection(){  
        Connection con=null;  
        try{  
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "");
        
        }catch(Exception e){System.out.println(e);}  
        return con;  
    }  
    public static int AddEmp(cus e){  
        int status=0;  
        try{  
            Connection con=cusdbhandler.getConnection();  
            PreparedStatement ps=con.prepareStatement(  
                         "insert into bookroom(room,adult,checkin,checkout,child) values (?,?,?,?,?)");  
            ps.setString(1,e.getRoom());
            ps.setInt(2,e.getPerson());
            ps.setString(3,e.getCheckIn());
            ps.setString(4,e.getCheckOut());
            ps.setString(5,e.getChildren()); 
              
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return status;  
    }
}  