/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;


public class cus {
    
private int id,person;  
    private String room,checkin,checkout,child;  
    
public int getId() {  
    return id;  
}  
public void setId(int id) {  
    this.id = id;  
}  
public String getRoom() {  
    return room;  
}  
public void setRoom(String room) {  
    this.room = room;  
}  
public int getPerson() {  
    return person;  
}  
public void setPerson(int person) {  
    this.person = person;  
}
public String getCheckIn() {  
    return checkin;  
}  
public void setCheckIn(String checkin) {  
    this.checkin = checkin;  
}  
public String getCheckOut() {  
    return checkout;  
}  
public void setCheckOut(String checkout) {  
    this.checkout = checkout;  
}  
public String getChildren() {  
    return child;  
}  
public void setChildren(String child) {  
    this.child = child;  
}   
}
