package Model;


import Model.cus_det;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Intel
 */
public class CusDBHandler_Customer {
    
public static Connection getConnection(){  
        Connection con=null;  
        try{  
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "");
        
        }catch(Exception e){System.out.println(e);}  
        return con;  
    }  
    public static int AddEmp_Customer(cus_det e){  
        int status=0;  
        try{  
            Connection con=CusDBHandler_Customer.getConnection();  
            PreparedStatement ps=con.prepareStatement(  
                         "insert into details(full_name,last_name,email,mobile) values (?,?,?,?)");  
            ps.setString(1,e.getFName());  
            ps.setString(2,e.getLName()); 
            ps.setString(3,e.getEmail()); 
            ps.setInt(4,e.getMobile()); 
              
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return status;  
    }  
}  